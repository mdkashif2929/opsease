import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingCart, Cog, Wallet, AlertTriangle } from "lucide-react";

export default function OverviewCards() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="border border-border">
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="h-3 bg-gray-200 rounded w-full"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Active Orders",
      value: stats?.activeOrders || 0,
      icon: ShoppingCart,
      color: "bg-primary",
      change: "+12%",
      changeText: "from last month",
      positive: true,
    },
    {
      title: "Production Progress",
      value: "78%",
      icon: Cog,
      color: "bg-primary",
      showProgress: true,
      progressValue: 78,
    },
    {
      title: "Today's Expenses",
      value: `₹${stats?.todayExpenses?.toLocaleString() || 0}`,
      icon: Wallet,
      color: "bg-primary",
      change: "-8%",
      changeText: "from yesterday",
      positive: false,
    },
    {
      title: "Stock Alerts",
      value: stats?.lowStockCount || 0,
      icon: AlertTriangle,
      color: "bg-yellow-100",
      iconColor: "text-yellow-600",
      changeText: "Items need reordering",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => (
        <Card key={index} className="border border-border hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm font-medium">{card.title}</p>
                <p className="text-3xl font-bold text-foreground">{card.value}</p>
              </div>
              <div className={`${card.color} ${card.color === 'bg-yellow-100' ? '' : 'bg-opacity-10'} p-3 rounded-lg`}>
                <card.icon className={`${card.iconColor || 'text-primary'} h-6 w-6`} />
              </div>
            </div>
            {card.showProgress && (
              <div className="mt-4">
                <div className="bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-primary h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${card.progressValue}%` }}
                  ></div>
                </div>
              </div>
            )}
            {card.change && (
              <div className="mt-4 flex items-center text-sm">
                <span className={`font-medium ${card.positive ? 'text-green-600' : 'text-red-600'}`}>
                  {card.change}
                </span>
                <span className="text-muted-foreground ml-1">{card.changeText}</span>
              </div>
            )}
            {card.changeText && !card.change && (
              <div className="mt-4 flex items-center text-sm">
                <span className="text-muted-foreground">{card.changeText}</span>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
