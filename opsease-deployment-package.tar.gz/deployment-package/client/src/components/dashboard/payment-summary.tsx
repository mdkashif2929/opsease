import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText } from "lucide-react";

export default function PaymentSummary() {
  const { data: payments, isLoading } = useQuery({
    queryKey: ["/api/payments"],
  });

  const { data: employees } = useQuery({
    queryKey: ["/api/employees"],
  });

  const weeklyWages = payments?.reduce((sum: number, payment: any) => 
    sum + parseFloat(payment.netAmount || 0), 0
  ) || 0;

  const pendingPayments = payments?.filter((payment: any) => 
    payment.status === 'pending'
  ).reduce((sum: number, payment: any) => 
    sum + parseFloat(payment.netAmount || 0), 0
  ) || 0;

  const dailyRateWorkers = employees?.filter((emp: any) => 
    emp.paymentType === 'daily_rate'
  ).length || 0;

  const pieceRateWorkers = employees?.filter((emp: any) => 
    emp.paymentType === 'piece_rate'
  ).length || 0;

  if (isLoading) {
    return (
      <Card className="border border-border">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-gray-200 rounded w-1/2"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
            <div className="h-10 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-border">
      <CardHeader className="pb-4">
        <h3 className="text-lg font-semibold text-foreground">Payment Summary</h3>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-muted-foreground">This Week's Wages</p>
            <p className="text-2xl font-bold text-foreground">
              ₹{weeklyWages.toLocaleString()}
            </p>
          </div>
          
          <div className="p-4 bg-yellow-50 rounded-lg">
            <p className="text-sm text-muted-foreground">Pending Payments</p>
            <p className="text-2xl font-bold text-foreground">
              ₹{pendingPayments.toLocaleString()}
            </p>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-foreground">Daily Rate Workers</span>
              <span className="text-sm font-semibold text-foreground">
                {dailyRateWorkers} people
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-foreground">Piece Rate Workers</span>
              <span className="text-sm font-semibold text-foreground">
                {pieceRateWorkers} people
              </span>
            </div>
          </div>
          
          <Button 
            className="w-full bg-primary hover:bg-primary/90 text-white"
            onClick={() => window.location.href = '/payments'}
          >
            <FileText className="h-4 w-4 mr-2" />
            Generate Payslips
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
