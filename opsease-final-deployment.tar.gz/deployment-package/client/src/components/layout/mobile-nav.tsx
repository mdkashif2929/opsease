import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { LucideIcon } from "lucide-react";

interface NavigationItem {
  path: string;
  label: string;
  icon: LucideIcon;
}

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
  navigationItems: NavigationItem[];
}

export default function MobileNav({ isOpen, onClose, navigationItems }: MobileNavProps) {
  const [location] = useLocation();
  const { user } = useAuth();

  if (!isOpen) return null;

  return (
    <div className="lg:hidden bg-primary/95 backdrop-blur-sm">
      <div className="px-4 py-4 space-y-2">
        {/* User Profile */}
        <div className="flex items-center space-x-3 pb-4 border-b border-white/20">
          <Avatar className="h-10 w-10 border-2 border-white">
            <AvatarImage src={user?.profileImageUrl || ""} alt="Profile" />
            <AvatarFallback className="bg-white text-primary font-semibold">
              {user?.firstName?.[0] || user?.email?.[0] || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="text-white">
            <div className="font-medium text-sm">
              {user?.firstName && user?.lastName 
                ? `${user.firstName} ${user.lastName}`
                : user?.email || "User"
              }
            </div>
            <div className="text-xs text-white/75">Export Manager</div>
          </div>
        </div>

        {/* Navigation Items */}
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path || 
            (item.path !== "/" && location.startsWith(item.path));
          
          return (
            <Link key={item.path} href={item.path}>
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-white/10 px-3 py-2 text-sm ${
                  isActive ? "bg-white/20" : ""
                }`}
                onClick={onClose}
              >
                <Icon className="h-4 w-4 mr-3" />
                {item.label}
              </Button>
            </Link>
          );
        })}

        {/* Logout Button */}
        <div className="pt-4 border-t border-white/20">
          <Button
            variant="ghost"
            className="w-full justify-start text-white hover:bg-white/10 px-3 py-2 text-sm"
            onClick={() => window.location.href = "/api/logout"}
          >
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
}
