import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { 
  Factory, 
  BarChart3, 
  ShoppingCart, 
  Cog, 
  Wallet, 
  Package, 
  Users,
  UserCheck, 
  DollarSign, 
  FileText, 
  Building,
  Truck,
  BookOpen,
  Menu,
  X
} from "lucide-react";
import MobileNav from "./mobile-nav";

const navigationItems = [
  { path: "/", label: "Dashboard", icon: BarChart3 },
  { path: "/orders", label: "Orders", icon: ShoppingCart },
  { path: "/production", label: "Production", icon: Cog },
  { path: "/expenses", label: "Expenses", icon: Wallet },
  { path: "/stock", label: "Stock", icon: Package },
  { path: "/employees", label: "Employees", icon: Users },
  { path: "/attendance", label: "Attendance", icon: UserCheck },
  { path: "/payments", label: "Payments", icon: DollarSign },
  { path: "/invoices", label: "Invoices", icon: FileText },
  { path: "/customers", label: "Customers", icon: Building },
  { path: "/suppliers", label: "Suppliers", icon: Truck },
  { path: "/ledger", label: "Ledger", icon: BookOpen },
];

export default function Header() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      <header className="bg-primary shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/">
              <div className="flex items-center space-x-3 cursor-pointer">
                <div className="bg-white rounded-lg p-2">
                  <Factory className="text-primary h-5 w-5" />
                </div>
                <h1 className="text-white text-xl font-bold">OpsEase</h1>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex space-x-0.5">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.path || 
                  (item.path !== "/" && location.startsWith(item.path));
                
                return (
                  <Link key={item.path} href={item.path}>
                    <Button
                      variant="ghost"
                      className={`text-white hover:bg-primary/80 px-2 py-2 text-xs font-medium transition-colors ${
                        isActive ? "bg-primary/80" : ""
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5 mr-1" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
            </nav>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden text-white hover:bg-primary/80 mr-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>

            {/* User Profile */}
            <div className="flex items-center space-x-4">
              <div className="hidden md:block text-white text-sm text-right">
                <div className="font-medium">
                  {user?.firstName && user?.lastName 
                    ? `${user.firstName} ${user.lastName}`
                    : user?.email || "User"
                  }
                </div>
                <div className="text-xs text-white/75">Export Manager</div>
              </div>
              <Avatar className="h-10 w-10 border-2 border-white">
                <AvatarImage src={user?.profileImageUrl || ""} alt="Profile" />
                <AvatarFallback className="bg-white text-primary font-semibold">
                  {user?.firstName?.[0] || user?.email?.[0] || "U"}
                </AvatarFallback>
              </Avatar>
              <Button
                variant="ghost"
                size="sm"
                className="hidden md:flex text-white hover:bg-primary/80"
                onClick={() => window.location.href = "/api/logout"}
              >
                Logout
              </Button>
              {/* Logout icon for mobile */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden text-white hover:bg-primary/80"
                onClick={() => window.location.href = "/api/logout"}
                title="Logout"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                  <polyline points="16,17 21,12 16,7"/>
                  <line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <MobileNav 
        isOpen={mobileMenuOpen} 
        onClose={() => setMobileMenuOpen(false)}
        navigationItems={navigationItems}
      />
    </>
  );
}
