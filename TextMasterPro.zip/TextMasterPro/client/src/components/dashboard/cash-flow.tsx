import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Truck, Users, Zap, Settings, Plus } from "lucide-react";

export default function CashFlow() {
  const { data: expenses, isLoading } = useQuery({
    queryKey: ["/api/expenses", { 
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0]
    }],
  });

  const todayExpenses = expenses || [];
  const totalExpenses = todayExpenses.reduce((sum: number, expense: any) => 
    sum + parseFloat(expense.amount || 0), 0
  );

  // Group expenses by category
  const expensesByCategory = todayExpenses.reduce((acc: any, expense: any) => {
    const category = expense.category || 'other';
    if (!acc[category]) {
      acc[category] = 0;
    }
    acc[category] += parseFloat(expense.amount || 0);
    return acc;
  }, {});

  const categoryIcons: Record<string, any> = {
    raw_materials: { icon: Truck, color: "bg-blue-100 text-blue-600", label: "Raw Materials" },
    wages: { icon: Users, color: "bg-green-100 text-green-600", label: "Worker Wages" },
    utilities: { icon: Zap, color: "bg-yellow-100 text-yellow-600", label: "Utilities" },
    maintenance: { icon: Settings, color: "bg-purple-100 text-purple-600", label: "Maintenance" },
  };

  if (isLoading) {
    return (
      <Card className="border border-border">
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="h-16 bg-gray-200 rounded"></div>
              <div className="h-16 bg-gray-200 rounded"></div>
            </div>
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-12 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-border">
      <CardHeader className="pb-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Daily Cash Flow</h3>
          <Button
            variant="ghost"
            size="sm"
            className="text-primary hover:text-primary/80 text-sm font-medium"
          >
            <Download className="h-4 w-4 mr-1" />
            Export PDF
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {/* Cash flow summary */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-sm text-muted-foreground">Today's Income</p>
            <p className="text-xl font-bold text-green-600">₹45,000</p>
          </div>
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <p className="text-sm text-muted-foreground">Today's Expense</p>
            <p className="text-xl font-bold text-red-600">₹{totalExpenses.toLocaleString()}</p>
          </div>
        </div>

        {/* Recent expense categories */}
        <div className="space-y-3">
          {Object.entries(categoryIcons).map(([key, config]) => {
            const amount = expensesByCategory[key] || 0;
            const Icon = config.icon;
            
            return (
              <div key={key} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${config.color}`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{config.label}</span>
                </div>
                <span className="text-sm font-semibold text-foreground">
                  ₹{amount.toLocaleString()}
                </span>
              </div>
            );
          })}
        </div>

        {/* Add expense button */}
        <Button 
          className="w-full mt-6 bg-primary hover:bg-primary/90 text-white"
          onClick={() => window.location.href = '/expenses'}
        >
          <Plus className="h-4 w-4 mr-2" />
          Add New Expense
        </Button>
      </CardContent>
    </Card>
  );
}