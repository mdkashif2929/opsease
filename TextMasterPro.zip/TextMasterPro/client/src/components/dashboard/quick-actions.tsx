import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Plus, Clock, Receipt, FileText } from "lucide-react";

export default function QuickActions() {
  const actions = [
    {
      icon: Plus,
      label: "Add New Order",
      href: "/orders",
      color: "bg-primary/10 text-primary",
    },
    {
      icon: Clock,
      label: "Mark Attendance",
      href: "/attendance",
      color: "bg-primary/10 text-primary",
    },
    {
      icon: Receipt,
      label: "Add Expense",
      href: "/expenses",
      color: "bg-primary/10 text-primary",
    },
    {
      icon: FileText,
      label: "Generate Invoice",
      href: "/invoices",
      color: "bg-primary/10 text-primary",
    },
  ];

  return (
    <Card className="border border-border">
      <CardHeader className="pb-4">
        <h3 className="text-lg font-semibold text-foreground">Quick Actions</h3>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {actions.map((action, index) => (
            <Link key={index} href={action.href}>
              <Button
                variant="ghost"
                className="w-full justify-start p-3 h-auto border border-border hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${action.color}`}>
                    <action.icon className="h-4 w-4" />
                  </div>
                  <span className="font-medium text-foreground">{action.label}</span>
                </div>
              </Button>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
