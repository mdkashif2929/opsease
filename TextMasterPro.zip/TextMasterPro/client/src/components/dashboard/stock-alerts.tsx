import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

export default function StockAlerts() {
  const { data: lowStock, isLoading } = useQuery({
    queryKey: ["/api/stock/low-stock"],
  });

  const getSeverityLevel = (currentQuantity: number, reorderLevel: number) => {
    const ratio = currentQuantity / reorderLevel;
    if (ratio <= 0.5) return { level: "Critical", color: "bg-red-100 text-red-800" };
    if (ratio <= 0.8) return { level: "Low", color: "bg-yellow-100 text-yellow-800" };
    return { level: "Medium", color: "bg-orange-100 text-orange-800" };
  };

  if (isLoading) {
    return (
      <Card className="border border-border">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-gray-200 rounded w-1/2"></div>
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-200 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-border">
      <CardHeader className="pb-4">
        <h3 className="text-lg font-semibold text-foreground">Stock Alerts</h3>
      </CardHeader>
      <CardContent>
        {!lowStock || lowStock.length === 0 ? (
          <div className="text-center text-muted-foreground py-4">
            <p className="text-sm">All stock levels are good</p>
          </div>
        ) : (
          <div className="space-y-3">
            {lowStock.slice(0, 3).map((item: any) => {
              const severity = getSeverityLevel(item.currentQuantity, item.reorderLevel);
              
              return (
                <div key={item.id} className={`p-3 rounded-lg border border-gray-200`}>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium text-foreground">{item.itemName}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.currentQuantity} {item.unit} remaining
                      </p>
                    </div>
                    <Badge className={`text-xs ${severity.color}`}>
                      {severity.level}
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        
        <Link href="/stock">
          <Button 
            variant="outline" 
            className="w-full mt-4 border-primary text-primary hover:bg-primary hover:text-white"
          >
            Manage Stock
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
