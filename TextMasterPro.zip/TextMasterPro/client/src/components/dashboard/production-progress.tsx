import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function ProductionProgress() {
  const { data: plans, isLoading } = useQuery({
    queryKey: ["/api/production-plans"],
  });

  const stages = [
    { name: "Cutting", progress: 85, team: "Cutting Team A", workers: 8 },
    { name: "Stitching", progress: 72, team: "Stitching Team B", workers: 12 },
    { name: "Quality Check", progress: 68, team: "QC Team", workers: 4 },
    { name: "Packaging", progress: 45, team: "Packaging Team", workers: 6 },
  ];

  if (isLoading) {
    return (
      <Card className="border border-border">
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i}>
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-full"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-border">
      <CardHeader className="pb-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Production Progress</h3>
          <Select defaultValue="week">
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {/* Production stages progress bars */}
        <div className="space-y-6">
          {stages.map((stage, index) => (
            <div key={index}>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-foreground">{stage.name}</span>
                <span className="text-sm text-muted-foreground">{stage.progress}%</span>
              </div>
              <div className="bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-primary h-3 rounded-full transition-all duration-500" 
                  style={{ width: `${stage.progress}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        {/* Team assignments */}
        <div className="mt-8 pt-6 border-t border-border">
          <h4 className="text-sm font-semibold text-foreground mb-4">Team Assignments</h4>
          <div className="space-y-3">
            {stages.map((stage, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-sm text-foreground">{stage.team}</span>
                <Badge variant="secondary" className="text-xs">
                  {stage.workers} workers
                </Badge>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
