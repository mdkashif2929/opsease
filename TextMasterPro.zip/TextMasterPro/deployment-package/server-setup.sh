#!/bin/bash

# Initial server setup script for Contabo VPS
# Run this first before deploying the application

set -e

echo "🚀 Setting up Contabo VPS for OpsEase deployment..."

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Please run as root${NC}"
    exit 1
fi

# Update system
echo -e "${GREEN}📦 Updating system packages...${NC}"
apt update && apt upgrade -y

# Install essential packages
echo -e "${GREEN}📦 Installing essential packages...${NC}"
apt install -y curl wget git unzip software-properties-common htop ufw fail2ban

# Install Node.js 20
echo -e "${GREEN}📦 Installing Node.js 20...${NC}"
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs

# Verify Node.js installation
NODE_VERSION=$(node --version)
NPM_VERSION=$(npm --version)
echo -e "${GREEN}✓ Node.js installed: $NODE_VERSION${NC}"
echo -e "${GREEN}✓ npm installed: $NPM_VERSION${NC}"

# Install PostgreSQL 15
echo -e "${GREEN}🗄️ Installing PostgreSQL 15...${NC}"
apt install -y postgresql postgresql-contrib

# Start and enable PostgreSQL
systemctl start postgresql
systemctl enable postgresql

# Install Nginx
echo -e "${GREEN}🌐 Installing Nginx...${NC}"
apt install -y nginx
systemctl start nginx
systemctl enable nginx

# Install PM2
echo -e "${GREEN}📊 Installing PM2...${NC}"
npm install -g pm2

# Install Certbot for SSL
echo -e "${GREEN}🔒 Installing Certbot...${NC}"
apt install -y certbot python3-certbot-nginx

# Configure firewall
echo -e "${GREEN}🔥 Configuring firewall...${NC}"
ufw --force enable
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 'Nginx Full'
ufw allow 80
ufw allow 443

# Configure fail2ban
echo -e "${GREEN}🛡️ Configuring fail2ban...${NC}"
systemctl enable fail2ban
systemctl start fail2ban

# Create application directory
echo -e "${GREEN}📁 Creating application directory...${NC}"
mkdir -p /var/www/opsease
chown -R www-data:www-data /var/www/opsease
chmod -R 755 /var/www/opsease

# Create log directory
mkdir -p /var/log/opsease
chown -R www-data:www-data /var/log/opsease

# Set up PostgreSQL
echo -e "${GREEN}🗄️ Setting up PostgreSQL database...${NC}"
sudo -u postgres psql << 'EOF'
CREATE DATABASE opsease;
CREATE USER opsease_user WITH PASSWORD 'OpsEase2025!SecureDB';
GRANT ALL PRIVILEGES ON DATABASE opsease TO opsease_user;
GRANT ALL ON SCHEMA public TO opsease_user;
ALTER USER opsease_user CREATEDB;
\q
EOF

# Configure PostgreSQL for local connections
echo "local   opsease         opsease_user                            md5" >> /etc/postgresql/15/main/pg_hba.conf
systemctl restart postgresql

# Test database connection
echo -e "${GREEN}🔍 Testing database connection...${NC}"
if sudo -u postgres psql -h localhost -U opsease_user -d opsease -c "SELECT version();" > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Database connection successful${NC}"
else
    echo -e "${RED}❌ Database connection failed${NC}"
fi

# Set up PM2 startup
echo -e "${GREEN}📊 Setting up PM2 startup...${NC}"
pm2 startup

# Create backup directory
mkdir -p /root/backups

# Set timezone to IST
echo -e "${GREEN}🕐 Setting timezone to Asia/Kolkata...${NC}"
timedatectl set-timezone Asia/Kolkata

# Show system information
echo -e "${GREEN}📋 System Information:${NC}"
echo "OS: $(lsb_release -d | cut -f2)"
echo "Kernel: $(uname -r)"
echo "Memory: $(free -h | grep Mem | awk '{print $2}')"
echo "Disk: $(df -h / | awk 'NR==2{print $2}')"
echo "CPU Cores: $(nproc)"
echo "Timezone: $(timedatectl | grep "Time zone" | awk '{print $3}')"

echo -e "${GREEN}✅ Server setup completed successfully!${NC}"
echo ""
echo -e "${GREEN}Next steps:${NC}"
echo -e "${GREEN}1. Upload your application files to /var/www/opsease${NC}"
echo -e "${GREEN}2. Run the application deployment script${NC}"
echo -e "${GREEN}3. Configure SSL certificate${NC}"
echo -e "${GREEN}4. Set up DNS for maketrack.zaf-tech.io${NC}"

echo ""
echo -e "${GREEN}🔧 Useful commands:${NC}"
echo "View system status: systemctl status nginx postgresql"
echo "View firewall status: ufw status"
echo "View logs: journalctl -f"
echo "Monitor resources: htop"