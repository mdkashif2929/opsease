# OpsEase Deployment Package for Contabo VPS

## Server Information
- **IP**: 5.189.171.19
- **Domain**: maketrack.zaf-tech.io
- **Server**: Contabo Cloud VPS 20 (6 vCPU, 12GB RAM, 100GB NVMe)

## Quick Start

1. **Upload this entire folder** to your server at `/var/www/opsease/`
2. **Run the setup script**: `sudo ./quick-deploy.sh`
3. **Configure SSL**: `sudo certbot --nginx -d maketrack.zaf-tech.io -d www.maketrack.zaf-tech.io`
4. **Set DNS**: Point maketrack.zaf-tech.io to 5.189.171.19

## Files Included

- `quick-deploy.sh` - Automated setup script
- `CONTABO_DEPLOYMENT.md` - Complete deployment guide
- `ecosystem.config.js` - PM2 configuration
- `nginx.conf` - Nginx configuration
- `.env.example` - Environment variables template
- `docker-compose.yml` - Docker setup (alternative)
- `Dockerfile` - Container configuration
- `deploy.sh` - Application deployment script
- `backup-script.sh` - Database backup script

## Post-Deployment

Your application will be available at: **https://maketrack.zaf-tech.io**

For support, refer to the troubleshooting section in CONTABO_DEPLOYMENT.md