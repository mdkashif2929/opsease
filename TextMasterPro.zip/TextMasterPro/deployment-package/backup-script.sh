#!/bin/bash

# OpsEase Backup Script for Contabo VPS
# Backs up database and application files

BACKUP_DIR="/root/backups"
DATE=$(date +%Y%m%d_%H%M%S)
APP_DIR="/var/www/opsease"

# Create backup directory
mkdir -p $BACKUP_DIR

echo "Starting backup process..."

# Database backup
echo "Backing up database..."
pg_dump -h localhost -U opsease_user opsease > $BACKUP_DIR/opsease_db_$DATE.sql

if [ $? -eq 0 ]; then
    echo "✓ Database backup completed: opsease_db_$DATE.sql"
else
    echo "✗ Database backup failed"
    exit 1
fi

# Application backup
echo "Backing up application files..."
tar -czf $BACKUP_DIR/opsease_app_$DATE.tar.gz -C /var/www opsease

if [ $? -eq 0 ]; then
    echo "✓ Application backup completed: opsease_app_$DATE.tar.gz"
else
    echo "✗ Application backup failed"
    exit 1
fi

# Clean old backups (keep last 7 days)
echo "Cleaning old backups..."
find $BACKUP_DIR -name "opsease_*" -mtime +7 -delete

# Show backup size
echo "Backup completed successfully!"
echo "Backup location: $BACKUP_DIR"
echo "Files created:"
ls -lh $BACKUP_DIR/opsease_*$DATE*

# Calculate total backup size
TOTAL_SIZE=$(du -sh $BACKUP_DIR | cut -f1)
echo "Total backup directory size: $TOTAL_SIZE"