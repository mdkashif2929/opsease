import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { AlertTriangle, Calendar, DollarSign } from "lucide-react";

export default function Alerts() {
  const { data: lowStock } = useQuery({
    queryKey: ["/api/stock/low-stock"],
  });

  const { data: orders } = useQuery({
    queryKey: ["/api/orders"],
  });

  // Calculate alerts
  const alerts = [];

  // Low stock alerts
  if (lowStock?.length > 0) {
    lowStock.slice(0, 2).forEach((item: any) => {
      alerts.push({
        type: "warning",
        icon: AlertTriangle,
        title: "Low Stock Alert",
        message: `${item.itemName} running low - ${item.currentQuantity} ${item.unit} left`,
        color: "bg-yellow-50 border-yellow-200 text-yellow-600",
      });
    });
  }

  // Production delay alerts (mock for now)
  const delayedOrders = orders?.filter((order: any) => order.status === "delayed") || [];
  if (delayedOrders.length > 0) {
    alerts.push({
      type: "error",
      icon: Calendar,
      title: "Production Delay",
      message: `Order ${delayedOrders[0].orderId} is behind schedule`,
      color: "bg-red-50 border-red-200 text-red-600",
    });
  }

  // Payment due alerts (mock)
  alerts.push({
    type: "info",
    icon: DollarSign,
    title: "Payment Due",
    message: "Worker payments due in 2 days",
    color: "bg-blue-50 border-blue-200 text-blue-600",
  });

  return (
    <Card className="border border-border">
      <CardHeader className="pb-4">
        <h3 className="text-lg font-semibold text-foreground">Alerts & Notifications</h3>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ? (
          <div className="text-center text-muted-foreground py-4">
            <p className="text-sm">No alerts at this time</p>
          </div>
        ) : (
          <div className="space-y-3">
            {alerts.slice(0, 3).map((alert, index) => (
              <div key={index} className={`p-3 rounded-lg border ${alert.color}`}>
                <div className="flex items-start space-x-3">
                  <alert.icon className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">{alert.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">{alert.message}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
