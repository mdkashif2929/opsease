#!/bin/bash

# OpsEase Update Script
# Use this script to update the application after making changes

set -e

APP_DIR="/var/www/opsease"
BACKUP_DIR="/root/backups"
DATE=$(date +%Y%m%d_%H%M%S)

echo "🔄 Starting OpsEase application update..."

# Check if we're in the right directory
if [ ! -f "$APP_DIR/package.json" ]; then
    echo "❌ Error: Application not found at $APP_DIR"
    exit 1
fi

cd $APP_DIR

# Create backup before update
echo "💾 Creating backup before update..."
mkdir -p $BACKUP_DIR
pg_dump -h localhost -U opsease_user opsease > $BACKUP_DIR/pre_update_db_$DATE.sql
tar -czf $BACKUP_DIR/pre_update_app_$DATE.tar.gz -C /var/www opsease

# Stop the application
echo "⏹️ Stopping application..."
pm2 stop opsease

# Update dependencies
echo "📦 Installing/updating dependencies..."
npm install --production

# Build the application
echo "🏗️ Building application..."
npm run build

# Run database migrations
echo "🗄️ Running database migrations..."
npm run db:push

# Restart the application
echo "🚀 Restarting application..."
pm2 restart opsease

# Wait a moment for the app to start
sleep 3

# Health check
echo "🏥 Performing health check..."
if curl -f http://localhost:5000/api/health > /dev/null 2>&1; then
    echo "✅ Update completed successfully!"
    echo "🌐 Application is running at: https://maketrack.zaf-tech.io"
else
    echo "❌ Health check failed. Rolling back..."
    pm2 stop opsease
    
    # Restore from backup
    echo "🔄 Restoring from backup..."
    tar -xzf $BACKUP_DIR/pre_update_app_$DATE.tar.gz -C /var/www/
    psql -h localhost -U opsease_user -d opsease < $BACKUP_DIR/pre_update_db_$DATE.sql
    
    pm2 restart opsease
    echo "⚠️ Application has been rolled back to previous version"
    exit 1
fi

# Show application status
echo "📊 Application status:"
pm2 status opsease